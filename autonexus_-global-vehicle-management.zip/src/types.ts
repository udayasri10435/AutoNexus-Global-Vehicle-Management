export type VehicleStatus = 'available' | 'reserved' | 'sold' | 'repairing';

export interface Vehicle {
  id: string;
  make: string;
  model: string;
  year: number;
  vin: string;
  price: number;
  status: VehicleStatus;
  image: string;
  mileage: number;
}

export type RepairStatus = 'pending' | 'in-progress' | 'completed' | 'cancelled';

export interface RepairOrder {
  id: string;
  vehicleId: string;
  customerName: string;
  description: string;
  status: RepairStatus;
  estimatedCost: number;
  createdAt: string;
  technicianId: string;
}

export interface Part {
  id: string;
  name: string;
  sku: string;
  quantity: number;
  price: number;
  category: string;
}

export type OfferType = 'buy' | 'sell';
export type OfferStatus = 'pending' | 'accepted' | 'rejected';

export interface Offer {
  id: string;
  vehicleId: string;
  type: OfferType;
  amount: number;
  status: OfferStatus;
  customerName: string;
  createdAt: string;
  estimatedCompletionDate: string;
}

export type ServiceStatus = 'healthy' | 'degraded' | 'down';

export interface Microservice {
  id: string;
  name: string;
  domain: string;
  language: string;
  status: ServiceStatus;
  latency: number;
}
