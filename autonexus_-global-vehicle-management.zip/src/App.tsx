import React, { useState, useMemo } from 'react';
import { 
  LayoutDashboard, 
  Car, 
  Wrench, 
  ShoppingCart, 
  Activity, 
  Settings, 
  Search, 
  Bell, 
  User,
  Package,
  ArrowUpRight,
  ArrowDownRight,
  ShieldCheck,
  Cpu,
  Database,
  Globe,
  X,
  Calendar,
  DollarSign,
  FileText,
  Clock,
  ArrowUpDown,
  Filter
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  Cell
} from 'recharts';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from './lib/utils';
import { 
  VEHICLES, 
  REPAIR_ORDERS, 
  PARTS, 
  OFFERS, 
  MICROSERVICES,
  LANGUAGES 
} from './constants';
import { Vehicle, RepairOrder, Part, Offer, Microservice, ServiceStatus } from './types';

// --- Components ---

const StatCard = ({ title, value, change, icon: Icon, trend }: { title: string, value: string, change: string, icon: any, trend: 'up' | 'down' }) => (
  <div className="card p-4 flex flex-col gap-2">
    <div className="flex justify-between items-start">
      <div className="p-2 bg-white/5 rounded-lg">
        <Icon className="w-5 h-5 text-accent" />
      </div>
      <div className={cn(
        "flex items-center text-xs font-medium",
        trend === 'up' ? "text-success" : "text-error"
      )}>
        {trend === 'up' ? <ArrowUpRight className="w-3 h-3 mr-1" /> : <ArrowDownRight className="w-3 h-3 mr-1" />}
        {change}
      </div>
    </div>
    <div>
      <p className="text-text-secondary text-sm font-medium">{title}</p>
      <h3 className="text-2xl font-bold mt-1">{value}</h3>
    </div>
  </div>
);

const SectionHeader = ({ title, subtitle }: { title: string, subtitle?: string }) => (
  <div className="mb-6">
    <h2 className="text-xl font-bold tracking-tight">{title}</h2>
    {subtitle && <p className="text-text-secondary text-sm">{subtitle}</p>}
  </div>
);

// --- Views ---

const DashboardView = () => {
  const chartData = [
    { name: 'Mon', revenue: 4500, repairs: 12 },
    { name: 'Tue', revenue: 5200, repairs: 15 },
    { name: 'Wed', revenue: 4800, repairs: 10 },
    { name: 'Thu', revenue: 6100, repairs: 18 },
    { name: 'Fri', revenue: 5900, repairs: 22 },
    { name: 'Sat', revenue: 7200, repairs: 25 },
    { name: 'Sun', revenue: 6800, repairs: 20 },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total Revenue" value="$142,500" change="+12.5%" icon={ShoppingCart} trend="up" />
        <StatCard title="Active Repairs" value="24" change="-3.2%" icon={Wrench} trend="down" />
        <StatCard title="Inventory Value" value="$2.4M" change="+5.4%" icon={Package} trend="up" />
        <StatCard title="System Uptime" value="99.98%" change="+0.01%" icon={Activity} trend="up" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card p-6">
          <SectionHeader title="Revenue Overview" subtitle="Weekly performance across all domains" />
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#262626" vertical={false} />
                <XAxis dataKey="name" stroke="#525252" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#525252" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(v) => `$${v}`} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#141414', border: '1px solid #262626', borderRadius: '8px' }}
                  itemStyle={{ color: '#ffffff' }}
                />
                <Area type="monotone" dataKey="revenue" stroke="#3b82f6" fillOpacity={1} fill="url(#colorRevenue)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card p-6">
          <SectionHeader title="Repair Throughput" subtitle="Daily completed repair orders" />
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#262626" vertical={false} />
                <XAxis dataKey="name" stroke="#525252" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#525252" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#141414', border: '1px solid #262626', borderRadius: '8px' }}
                  itemStyle={{ color: '#ffffff' }}
                />
                <Bar dataKey="repairs" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="card p-6 lg:col-span-2">
          <SectionHeader title="Recent Activity" subtitle="Latest events across the polyglot ecosystem" />
          <div className="space-y-4">
            {[
              { time: '2m ago', event: 'VIN Decoder (Rust) processed 5YJ3E1EA8PF', type: 'system' },
              { time: '15m ago', event: 'New Buy Order for Tesla Model 3 ($40,500)', type: 'business' },
              { time: '45m ago', event: 'Repair Order #RO-442 completed by Tech-1', type: 'operation' },
              { time: '1h ago', event: 'Inventory Reorder Engine (Clojure) triggered for Brake Pads', type: 'system' },
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-4 p-3 rounded-lg hover:bg-white/5 transition-colors">
                <div className="text-xs text-text-secondary w-16">{item.time}</div>
                <div className="flex-1 text-sm font-medium">{item.event}</div>
                <div className={cn(
                  "px-2 py-0.5 rounded text-[10px] uppercase font-bold tracking-wider",
                  item.type === 'system' ? "bg-accent/20 text-accent" : 
                  item.type === 'business' ? "bg-success/20 text-success" : "bg-warning/20 text-warning"
                )}>
                  {item.type}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="card p-6">
          <SectionHeader title="Service Distribution" subtitle="Language usage across 1,000 services" />
          <div className="space-y-3">
            {LANGUAGES.slice(0, 6).map((lang) => (
              <div key={lang.name} className="space-y-1">
                <div className="flex justify-between text-xs font-medium">
                  <span>{lang.name}</span>
                  <span className="text-text-secondary">{Math.floor(Math.random() * 150) + 50} services</span>
                </div>
                <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                  <div 
                    className="h-full rounded-full" 
                    style={{ backgroundColor: lang.color, width: `${Math.floor(Math.random() * 60) + 20}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const InventoryView = () => (
  <div className="space-y-6">
    <SectionHeader title="Vehicle Inventory" subtitle="Current stock and lifecycle status" />
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
      {VEHICLES.map((v) => (
        <div key={v.id} className="card group cursor-pointer">
          <div className="aspect-video relative overflow-hidden">
            <img src={v.image} alt={v.make} className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-500" referrerPolicy="no-referrer" />
            <div className="absolute top-2 right-2">
              <span className={cn(
                "px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider",
                v.status === 'available' ? "bg-success text-white" : 
                v.status === 'repairing' ? "bg-warning text-black" : "bg-accent text-white"
              )}>
                {v.status}
              </span>
            </div>
          </div>
          <div className="p-4">
            <div className="flex justify-between items-start mb-2">
              <div>
                <h3 className="font-bold text-lg">{v.make} {v.model}</h3>
                <p className="text-text-secondary text-sm">{v.year} • {v.mileage.toLocaleString()} miles</p>
              </div>
              <div className="text-right">
                <p className="font-bold text-accent text-lg">${v.price.toLocaleString()}</p>
                <p className="text-[10px] text-text-secondary font-mono">{v.vin}</p>
              </div>
            </div>
            <div className="flex gap-2 mt-4">
              <button className="flex-1 bg-white/5 hover:bg-white/10 py-2 rounded text-sm font-medium transition-colors">Details</button>
              <button className="flex-1 bg-accent hover:bg-accent/90 py-2 rounded text-sm font-medium transition-colors">Action</button>
            </div>
          </div>
        </div>
      ))}
    </div>

    <div className="mt-12">
      <SectionHeader title="Parts & Components" subtitle="Real-time inventory from 80+ microservices" />
      <div className="card overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-bottom border-border bg-white/5">
              <th className="p-4 text-xs font-bold uppercase tracking-wider text-text-secondary">Part Name</th>
              <th className="p-4 text-xs font-bold uppercase tracking-wider text-text-secondary">SKU</th>
              <th className="p-4 text-xs font-bold uppercase tracking-wider text-text-secondary">Category</th>
              <th className="p-4 text-xs font-bold uppercase tracking-wider text-text-secondary">Stock</th>
              <th className="p-4 text-xs font-bold uppercase tracking-wider text-text-secondary">Price</th>
              <th className="p-4 text-xs font-bold uppercase tracking-wider text-text-secondary">Status</th>
            </tr>
          </thead>
          <tbody>
            {PARTS.map((p) => (
              <tr key={p.id} className="border-bottom border-border hover:bg-white/5 transition-colors">
                <td className="p-4 font-medium">{p.name}</td>
                <td className="p-4 font-mono text-xs">{p.sku}</td>
                <td className="p-4 text-sm">{p.category}</td>
                <td className="p-4 text-sm">{p.quantity}</td>
                <td className="p-4 text-sm">${p.price}</td>
                <td className="p-4">
                  <span className={cn(
                    "px-2 py-0.5 rounded text-[10px] font-bold uppercase",
                    p.quantity > 50 ? "bg-success/20 text-success" : "bg-warning/20 text-warning"
                  )}>
                    {p.quantity > 50 ? 'In Stock' : 'Low Stock'}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  </div>
);

const RepairsView = () => (
  <div className="space-y-6">
    <div className="flex justify-between items-end">
      <SectionHeader title="Repair Operations" subtitle="Managing 150+ specialized repair services" />
      <button className="bg-accent hover:bg-accent/90 px-4 py-2 rounded text-sm font-bold mb-6 flex items-center gap-2">
        <Wrench className="w-4 h-4" /> New Repair Order
      </button>
    </div>
    
    <div className="grid grid-cols-1 gap-4">
      {REPAIR_ORDERS.map((ro) => (
        <div key={ro.id} className="card p-6 flex flex-col md:flex-row gap-6 items-start md:items-center">
          <div className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center shrink-0">
            <Wrench className="w-6 h-6 text-accent" />
          </div>
          <div className="flex-1">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-bold text-lg">{ro.description}</h3>
                <p className="text-text-secondary text-sm">Customer: {ro.customerName} • Vehicle ID: {ro.vehicleId}</p>
              </div>
              <div className={cn(
                "px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider",
                ro.status === 'in-progress' ? "bg-warning/20 text-warning" : 
                ro.status === 'pending' ? "bg-white/10 text-text-secondary" : "bg-success/20 text-success"
              )}>
                {ro.status}
              </div>
            </div>
            <div className="mt-4 flex flex-wrap gap-4 text-xs text-text-secondary">
              <div className="flex items-center gap-1"><Activity className="w-3 h-3" /> Tech Assigned: {ro.technicianId}</div>
              <div className="flex items-center gap-1"><ShoppingCart className="w-3 h-3" /> Est. Cost: ${ro.estimatedCost}</div>
              <div className="flex items-center gap-1"><LayoutDashboard className="w-3 h-3" /> Created: {new Date(ro.createdAt).toLocaleDateString()}</div>
            </div>
          </div>
          <div className="flex gap-2 w-full md:w-auto">
            <button className="flex-1 md:flex-none px-4 py-2 bg-white/5 hover:bg-white/10 rounded text-sm font-medium transition-colors">View Logs</button>
            <button className="flex-1 md:flex-none px-4 py-2 bg-accent hover:bg-accent/90 rounded text-sm font-medium transition-colors">Manage</button>
          </div>
        </div>
      ))}
    </div>
  </div>
);

const SystemHealthView = () => {
  const [filter, setFilter] = useState<string>('');
  const [domainFilter, setDomainFilter] = useState<string>('All');
  
  const domains = ['All', ...Array.from(new Set(MICROSERVICES.map(ms => ms.domain)))];
  
  const filteredServices = useMemo(() => {
    return MICROSERVICES.filter(ms => {
      const matchesSearch = ms.name.toLowerCase().includes(filter.toLowerCase()) || 
                           ms.language.toLowerCase().includes(filter.toLowerCase());
      const matchesDomain = domainFilter === 'All' || ms.domain === domainFilter;
      return matchesSearch && matchesDomain;
    });
  }, [filter, domainFilter]);

  return (
    <div className="space-y-6">
      <SectionHeader title="Polyglot Service Mesh" subtitle="Real-time status of 1,000 microservices across all languages" />
      
      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-secondary" />
          <input 
            type="text" 
            placeholder="Search services, languages..." 
            className="w-full bg-card border border-border rounded-lg py-2 pl-10 pr-4 text-sm focus:outline-none focus:border-accent transition-colors"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2 md:pb-0">
          {domains.map(d => (
            <button 
              key={d}
              onClick={() => setDomainFilter(d)}
              className={cn(
                "px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors",
                domainFilter === d ? "bg-accent text-white" : "bg-card border border-border hover:bg-white/5"
              )}
            >
              {d}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-10 gap-2">
        {filteredServices.map((ms) => (
          <motion.div 
            layout
            key={ms.id} 
            className="card p-2 flex flex-col items-center justify-center gap-2 group relative cursor-help"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
          >
            <div className={cn(
              "status-dot",
              ms.status === 'healthy' ? "status-dot-healthy" : 
              ms.status === 'degraded' ? "status-dot-degraded" : "status-dot-down"
            )} />
            <div className="text-[8px] font-mono text-text-secondary truncate w-full text-center">{ms.name.split('-')[0]}</div>
            
            {/* Tooltip */}
            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 p-3 bg-card border border-border rounded-lg shadow-2xl opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity z-50">
              <div className="flex justify-between items-start mb-2">
                <span className="text-[10px] font-bold uppercase text-accent">{ms.domain}</span>
                <span className="text-[10px] font-mono" style={{ color: LANGUAGES.find(l => l.name === ms.language)?.color }}>{ms.language}</span>
              </div>
              <h4 className="text-xs font-bold mb-1 truncate">{ms.name}</h4>
              <div className="flex justify-between text-[10px]">
                <span className="text-text-secondary">Latency</span>
                <span className="font-mono">{ms.latency}ms</span>
              </div>
              <div className="flex justify-between text-[10px] mt-1">
                <span className="text-text-secondary">Status</span>
                <span className={cn(
                  "font-bold uppercase",
                  ms.status === 'healthy' ? "text-success" : 
                  ms.status === 'degraded' ? "text-warning" : "text-error"
                )}>{ms.status}</span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

const MarketplaceView = ({ onOfferClick }: { onOfferClick: (offer: Offer) => void }) => {
  const [sortBy, setSortBy] = useState<'amount' | 'date' | 'status'>('date');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  const sortedOffers = useMemo(() => {
    return [...OFFERS].sort((a, b) => {
      let comparison = 0;
      if (sortBy === 'amount') {
        comparison = a.amount - b.amount;
      } else if (sortBy === 'date') {
        comparison = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      } else if (sortBy === 'status') {
        comparison = a.status.localeCompare(b.status);
      }
      return sortOrder === 'asc' ? comparison : -comparison;
    });
  }, [sortBy, sortOrder]);

  const toggleSort = (key: 'amount' | 'date' | 'status') => {
    if (sortBy === key) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(key);
      setSortOrder('desc');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <SectionHeader title="Buy & Sell Marketplace" subtitle="Managing offers from 100+ specialized negotiation services" />
        
        <div className="flex items-center gap-2 bg-card border border-border p-1 rounded-lg">
          <button 
            onClick={() => toggleSort('date')}
            className={cn(
              "px-3 py-1.5 rounded-md text-xs font-medium flex items-center gap-2 transition-colors",
              sortBy === 'date' ? "bg-accent text-white" : "text-text-secondary hover:bg-white/5"
            )}
          >
            Date {sortBy === 'date' && <ArrowUpDown className="w-3 h-3" />}
          </button>
          <button 
            onClick={() => toggleSort('amount')}
            className={cn(
              "px-3 py-1.5 rounded-md text-xs font-medium flex items-center gap-2 transition-colors",
              sortBy === 'amount' ? "bg-accent text-white" : "text-text-secondary hover:bg-white/5"
            )}
          >
            Amount {sortBy === 'amount' && <ArrowUpDown className="w-3 h-3" />}
          </button>
          <button 
            onClick={() => toggleSort('status')}
            className={cn(
              "px-3 py-1.5 rounded-md text-xs font-medium flex items-center gap-2 transition-colors",
              sortBy === 'status' ? "bg-accent text-white" : "text-text-secondary hover:bg-white/5"
            )}
          >
            Status {sortBy === 'status' && <ArrowUpDown className="w-3 h-3" />}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {sortedOffers.map((offer) => (
          <div 
            key={offer.id} 
            className="card p-6 cursor-pointer hover:border-accent/50 transition-colors group"
            onClick={() => onOfferClick(offer)}
          >
            <div className="flex justify-between items-start mb-4">
              <div className="flex items-center gap-3">
                <div className={cn(
                  "w-10 h-10 rounded-lg flex items-center justify-center",
                  offer.type === 'buy' ? "bg-success/20 text-success" : "bg-accent/20 text-accent"
                )}>
                  {offer.type === 'buy' ? <ArrowDownRight className="w-5 h-5" /> : <ArrowUpRight className="w-5 h-5" />}
                </div>
                <div>
                  <h3 className="font-bold group-hover:text-accent transition-colors">{offer.type === 'buy' ? 'Purchase Offer' : 'Sale Offer'}</h3>
                  <p className="text-xs text-text-secondary">From: {offer.customerName}</p>
                </div>
              </div>
              <div className={cn(
                "px-2 py-1 rounded text-[10px] font-bold uppercase",
                offer.status === 'pending' ? "bg-warning/20 text-warning" : "bg-success/20 text-success"
              )}>
                {offer.status}
              </div>
            </div>
            <div className="flex justify-between items-end">
              <div>
                <p className="text-xs text-text-secondary mb-1">Vehicle ID: {offer.vehicleId}</p>
                <p className="text-2xl font-bold">${offer.amount.toLocaleString()}</p>
                <p className="text-[10px] text-text-secondary mt-1">Submitted: {new Date(offer.createdAt).toLocaleDateString()}</p>
              </div>
              <div className="flex gap-2" onClick={(e) => e.stopPropagation()}>
                <button className="px-3 py-1.5 bg-white/5 hover:bg-white/10 rounded text-xs font-medium transition-colors">Reject</button>
                <button className="px-3 py-1.5 bg-accent hover:bg-accent/90 rounded text-xs font-medium transition-colors">Accept</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const OfferDetailsModal = ({ offer, onClose }: { offer: Offer, onClose: () => void }) => {
  const vehicle = VEHICLES.find(v => v.id === offer.vehicleId);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
      />
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 20 }}
        className="card w-full max-w-2xl relative z-10 overflow-hidden"
      >
        <div className="flex justify-between items-center p-6 border-b border-border">
          <div className="flex items-center gap-3">
            <div className={cn(
              "w-10 h-10 rounded-lg flex items-center justify-center",
              offer.type === 'buy' ? "bg-success/20 text-success" : "bg-accent/20 text-accent"
            )}>
              {offer.type === 'buy' ? <ShoppingCart className="w-5 h-5" /> : <Car className="w-5 h-5" />}
            </div>
            <div>
              <h2 className="text-xl font-bold">{offer.type === 'buy' ? 'Purchase' : 'Sale'} Offer Details</h2>
              <p className="text-text-secondary text-xs font-mono">ID: {offer.id}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/5 rounded-full transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-text-secondary">Offer Information</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <User className="w-4 h-4 text-accent" />
                  <div>
                    <p className="text-[10px] text-text-secondary uppercase">Customer</p>
                    <p className="text-sm font-medium">{offer.customerName}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <DollarSign className="w-4 h-4 text-success" />
                  <div>
                    <p className="text-[10px] text-text-secondary uppercase">Amount</p>
                    <p className="text-lg font-bold text-success">${offer.amount.toLocaleString()}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Calendar className="w-4 h-4 text-text-secondary" />
                  <div>
                    <p className="text-[10px] text-text-secondary uppercase">Submitted On</p>
                    <p className="text-sm font-medium">{new Date(offer.createdAt).toLocaleString()}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Activity className="w-4 h-4 text-warning" />
                  <div>
                    <p className="text-[10px] text-text-secondary uppercase">Status</p>
                    <span className={cn(
                      "px-2 py-0.5 rounded text-[10px] font-bold uppercase",
                      offer.status === 'pending' ? "bg-warning/20 text-warning" : "bg-success/20 text-success"
                    )}>
                      {offer.status}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Clock className="w-4 h-4 text-accent" />
                  <div>
                    <p className="text-[10px] text-text-secondary uppercase">
                      {offer.type === 'buy' ? 'Est. Delivery' : 'Est. Completion'}
                    </p>
                    <p className="text-sm font-medium">{new Date(offer.estimatedCompletionDate).toLocaleDateString()}</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-text-secondary">Vehicle Context</h3>
              {vehicle ? (
                <div className="bg-white/5 rounded-lg p-4 space-y-3">
                  <div className="flex gap-3">
                    <img src={vehicle.image} alt={vehicle.make} className="w-16 h-12 object-cover rounded" referrerPolicy="no-referrer" />
                    <div>
                      <p className="text-sm font-bold">{vehicle.make} {vehicle.model}</p>
                      <p className="text-[10px] text-text-secondary">{vehicle.year} • {vehicle.mileage.toLocaleString()} miles</p>
                    </div>
                  </div>
                  <div className="pt-2 border-t border-white/10 grid grid-cols-2 gap-2">
                    <div>
                      <p className="text-[10px] text-text-secondary uppercase">Market Value</p>
                      <p className="text-sm font-medium">${vehicle.price.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-text-secondary uppercase">VIN</p>
                      <p className="text-[10px] font-mono">{vehicle.vin}</p>
                    </div>
                  </div>
                </div>
              ) : (
                <p className="text-sm text-error">Vehicle data unavailable</p>
              )}
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-text-secondary">Negotiation Log</h3>
            <div className="space-y-2">
              {[
                { time: '10:00 AM', msg: 'Offer received from Customer Portal Service (Node.js)' },
                { time: '10:05 AM', msg: 'Valuation Service (Go) verified market price' },
                { time: '10:10 AM', msg: 'Fraud Detection Service (Rust) cleared offer' },
              ].map((log, i) => (
                <div key={i} className="flex gap-4 text-[10px] font-mono p-2 bg-white/5 rounded">
                  <span className="text-text-secondary">{log.time}</span>
                  <span>{log.msg}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="p-6 bg-white/5 flex justify-end gap-3">
          <button onClick={onClose} className="px-4 py-2 hover:bg-white/10 rounded text-sm font-medium transition-colors">Close</button>
          <button className="px-4 py-2 bg-error/20 text-error hover:bg-error/30 rounded text-sm font-bold transition-colors">Reject Offer</button>
          <button className="px-4 py-2 bg-success hover:bg-success/90 rounded text-sm font-bold transition-colors">Approve Offer</button>
        </div>
      </motion.div>
    </div>
  );
};

// --- Main Layout ---

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [selectedOffer, setSelectedOffer] = useState<Offer | null>(null);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'inventory', label: 'Inventory', icon: Car },
    { id: 'repairs', label: 'Repairs', icon: Wrench },
    { id: 'marketplace', label: 'Marketplace', icon: ShoppingCart },
    { id: 'system', label: 'System Health', icon: Activity },
  ];

  return (
    <div className="flex h-screen bg-bg overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 border-r border-border bg-card flex flex-col shrink-0 hidden lg:flex">
        <div className="p-6 flex items-center gap-3">
          <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center">
            <Cpu className="w-5 h-5 text-white" />
          </div>
          <h1 className="text-xl font-bold tracking-tighter">AUTONEXUS</h1>
        </div>
        
        <nav className="flex-1 px-4 space-y-2 mt-4">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all",
                activeTab === item.id 
                  ? "bg-accent text-white shadow-[0_0_15px_rgba(59,130,246,0.3)]" 
                  : "text-text-secondary hover:text-white hover:bg-white/5"
              )}
            >
              <item.icon className="w-4 h-4" />
              {item.label}
            </button>
          ))}
        </nav>

        <div className="p-4 mt-auto border-t border-border">
          <div className="flex items-center gap-3 p-2 rounded-lg hover:bg-white/5 cursor-pointer transition-colors">
            <div className="w-8 h-8 bg-white/10 rounded-full flex items-center justify-center">
              <User className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold truncate">Admin User</p>
              <p className="text-[10px] text-text-secondary truncate">udayasrimadhushan@gmail.com</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Header */}
        <header className="h-16 border-b border-border flex items-center justify-between px-6 bg-card/50 backdrop-blur-sm z-10">
          <div className="flex items-center gap-4 lg:hidden">
            <Cpu className="w-6 h-6 text-accent" />
            <h1 className="text-lg font-bold tracking-tighter">AUTONEXUS</h1>
          </div>
          <div className="hidden lg:flex items-center gap-2 text-xs text-text-secondary font-mono">
            <Globe className="w-3 h-3" /> Global Cluster: <span className="text-success">Active</span>
            <span className="mx-2 opacity-20">|</span>
            <Database className="w-3 h-3" /> Nodes: <span className="text-accent">1,024</span>
            <span className="mx-2 opacity-20">|</span>
            <ShieldCheck className="w-3 h-3" /> Security: <span className="text-success">Verified</span>
          </div>

          <div className="flex items-center gap-4">
            <button className="p-2 text-text-secondary hover:text-white transition-colors relative">
              <Bell className="w-5 h-5" />
              <span className="absolute top-2 right-2 w-2 h-2 bg-error rounded-full border-2 border-card"></span>
            </button>
            <button className="p-2 text-text-secondary hover:text-white transition-colors">
              <Settings className="w-5 h-5" />
            </button>
          </div>
        </header>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {activeTab === 'dashboard' && <DashboardView />}
              {activeTab === 'inventory' && <InventoryView />}
              {activeTab === 'repairs' && <RepairsView />}
              {activeTab === 'marketplace' && <MarketplaceView onOfferClick={setSelectedOffer} />}
              {activeTab === 'system' && <SystemHealthView />}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Footer / Status Bar */}
        <footer className="h-8 border-t border-border bg-card/50 flex items-center justify-between px-6 text-[10px] text-text-secondary font-mono">
          <div className="flex gap-4">
            <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-success"></span> API Gateway: OK</span>
            <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-success"></span> Kafka Cluster: OK</span>
            <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-warning"></span> VIN Decoder: High Latency</span>
          </div>
          <div>
            v4.2.0-stable • Build: 2026.03.28.0937
          </div>
        </footer>
      </main>

      <AnimatePresence>
        {selectedOffer && (
          <OfferDetailsModal 
            offer={selectedOffer} 
            onClose={() => setSelectedOffer(null)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}
