import { Vehicle, RepairOrder, Part, Offer, Microservice, ServiceStatus } from './types';

export const VEHICLES: Vehicle[] = [
  { id: 'v1', make: 'Tesla', model: 'Model 3', year: 2023, vin: '5YJ3E1EA8PF', price: 42000, status: 'available', image: 'https://picsum.photos/seed/tesla/400/300', mileage: 12000 },
  { id: 'v2', make: 'Ford', model: 'F-150 Lightning', year: 2022, vin: '1FTVW1EL8NW', price: 65000, status: 'repairing', image: 'https://picsum.photos/seed/ford/400/300', mileage: 8500 },
  { id: 'v3', make: 'Porsche', model: 'Taycan', year: 2024, vin: 'WP0AA2Y1XRS', price: 110000, status: 'reserved', image: 'https://picsum.photos/seed/porsche/400/300', mileage: 1500 },
  { id: 'v4', make: 'Rivian', model: 'R1S', year: 2023, vin: '7FCAR1A16PN', price: 89000, status: 'available', image: 'https://picsum.photos/seed/rivian/400/300', mileage: 4500 },
  { id: 'v5', make: 'BMW', model: 'i4 M50', year: 2023, vin: 'WBY73AW04PF', price: 72000, status: 'sold', image: 'https://picsum.photos/seed/bmw/400/300', mileage: 9200 },
];

export const REPAIR_ORDERS: RepairOrder[] = [
  { id: 'ro1', vehicleId: 'v2', customerName: 'John Doe', description: 'Battery diagnostic and software update', status: 'in-progress', estimatedCost: 450, createdAt: '2026-03-25T10:00:00Z', technicianId: 'tech1' },
  { id: 'ro2', vehicleId: 'v1', customerName: 'Jane Smith', description: 'Tire rotation and alignment', status: 'pending', estimatedCost: 120, createdAt: '2026-03-27T14:30:00Z', technicianId: 'tech2' },
  { id: 'ro3', vehicleId: 'v4', customerName: 'Robert Johnson', description: 'Brake pad replacement', status: 'completed', estimatedCost: 350, createdAt: '2026-03-20T09:15:00Z', technicianId: 'tech1' },
];

export const PARTS: Part[] = [
  { id: 'p1', name: 'Brake Pads (Front)', sku: 'BP-F-001', quantity: 24, price: 85, category: 'Brakes' },
  { id: 'p2', name: 'Air Filter', sku: 'AF-002', quantity: 150, price: 25, category: 'Filters' },
  { id: 'p3', name: 'Oil Filter (Synthetic)', sku: 'OF-003', quantity: 85, price: 18, category: 'Filters' },
  { id: 'p4', name: 'Wiper Blades (Set)', sku: 'WB-004', quantity: 42, price: 35, category: 'Accessories' },
];

export const OFFERS: Offer[] = [
  { id: 'o1', vehicleId: 'v1', type: 'buy', amount: 40500, status: 'pending', customerName: 'Alice Brown', createdAt: '2026-03-27T16:00:00Z', estimatedCompletionDate: '2026-04-05T12:00:00Z' },
  { id: 'o2', vehicleId: 'v4', type: 'sell', amount: 82000, status: 'accepted', customerName: 'Charlie Davis', createdAt: '2026-03-26T11:20:00Z', estimatedCompletionDate: '2026-03-30T17:00:00Z' },
];

export const LANGUAGES = [
  { name: 'Java', color: '#b07219' },
  { name: 'Go', color: '#00ADD8' },
  { name: 'Rust', color: '#dea584' },
  { name: 'Python', color: '#3572A5' },
  { name: 'Node.js', color: '#339933' },
  { name: 'C#', color: '#178600' },
  { name: 'Elixir', color: '#6e4a7e' },
  { name: 'Scala', color: '#c22d40' },
  { name: 'Ruby', color: '#701516' },
  { name: 'C++', color: '#f34b7d' },
  { name: 'Haskell', color: '#5e5086' },
];

export const MICROSERVICES: Microservice[] = Array.from({ length: 100 }).map((_, i) => {
  const lang = LANGUAGES[Math.floor(Math.random() * LANGUAGES.length)];
  const status: ServiceStatus = Math.random() > 0.95 ? 'down' : Math.random() > 0.85 ? 'degraded' : 'healthy';
  const domains = ['Lifecycle', 'Buying', 'Repair', 'Parts', 'Customer', 'Payments', 'AI', 'Infra'];
  
  return {
    id: `ms-${i}`,
    name: `${domains[Math.floor(Math.random() * domains.length)]}-${lang.name}-${i}`,
    domain: domains[Math.floor(Math.random() * domains.length)],
    language: lang.name,
    status,
    latency: Math.floor(Math.random() * 200) + 20,
  };
});
